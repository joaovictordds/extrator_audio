# Extrator de Áudio

Este é um pacote simples para extrair o áudio de vídeos do YouTube com base na URL do vídeo.

## Funcionalidades

- Faz o download de vídeos do YouTube
- Extrai o áudio e salva em formato MP3

## Instalação

```bash
pip install extrator_audio
`````````

## Licença 

- Este projeto está licenciado sob a [Licença MIT](LICENSE).
